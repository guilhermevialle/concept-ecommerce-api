export const toCents = (value: number): number => value * 100
