export const fromCents = (value: number): number => value / 100
