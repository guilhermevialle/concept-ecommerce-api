export type EventHandler<T> = (event: T) => Promise<void>
